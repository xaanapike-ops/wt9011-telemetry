
package com.example.wt9011telemetry;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView telemetryChart = findViewById(R.id.telemetryChart);
        telemetryChart.setText("Live telemetry active");
    }
}
